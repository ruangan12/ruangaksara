# Ruang Aksara - Static Website

Website sederhana untuk Ruang Aksara. Siap diupload ke **GitHub Pages**.

## Cara deploy ke GitHub Pages

1. Buat repository baru di GitHub (misal: `ruangaksara`).
2. Upload seluruh isi folder `ruangaksara_site` ke root repository (index.html di root).
3. Buka **Settings → Pages**, pilih branch `main` dan folder `/ (root)`, lalu **Save**.
4. Tunggu beberapa menit, lalu buka: `https://<username>.github.io/<repo-name>/`

## Kontak
Tombol WhatsApp sudah terpasang (nomor: +62 855-2388-7045).
