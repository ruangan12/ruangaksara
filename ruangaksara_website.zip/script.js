
// Simple interactivity for Ruang Aksara
console.log("Ruang Aksara - website loaded");

// Analytics placeholder (you can add GA or other scripts here)
